AstroFlight (working title) Alpha
An OpenGL learning project based on classical mechanics and astrophysics.

Reach the goal planet to win, drop your 3 terraforming boxes for bonus points.
Max 500 or 600 points per level.
Reaching the goal planet: 200 points
Terraforming a planet: 	  100 points
Terraforming a moon:	  200 points

Controls:
Arrows      Adjust rotation and launch speed
Spacebar    Launch spacecraft, drop terraforming boxes (after launch)
Shift       Precision mode (hold when using arrows)
F           Toggle fullscreen/windowed mode
W           Toggle wireframe mode
D           Toggle debug mode (FPS counter)
T           Toggle trajectory
C           Toggle center of mass
O           Toggle gravity gradient
G           Toggle GUI
R           Restart level
N           Next level
P           Pause
+/-         Adjust game speed (German keyboard layout)
Esc         Exit

Cheat:
Press Up Arrow after launch for a boost